package assignment02;
// 25, 26

import java.util.Scanner;
import java.util.Collection;
import java.util.ArrayList;
import com.google.common.collect.ArrayListMultimap;
public class Dictionary {
    static ArrayList<Word> finalList = new ArrayList<>();
    static ArrayList<String> partOfSpeech = new ArrayList<>();
    static Scanner input = new Scanner (System.in);
    public static void main(String[ ] args){
        System.out.println("! Loading data...\n" +
                "! Loading completed...\n" +
                "===== DICTIONARY 340 JAVA =====\n" +
                "----- Keywords: 19\n" +
                "----- Definitions: 61\n");
// Create an ArrayListMultimap and add keys and values to it.
        ArrayListMultimap<String, Word> dictionary = ArrayListMultimap.create();
        dictionary.put("arrow",Word.ARROW);
        dictionary.put("book",Word.BOOK1);
        dictionary.put("book",Word.BOOK2);
        dictionary.put("book",Word.BOOK3);
        dictionary.put("book",Word.BOOK4);
        dictionary.put("distinct",Word.DISTINCT1);
        dictionary.put("distinct",Word.DISTINCT2);
        dictionary.put("distinct",Word.DISTINCT3);
        dictionary.put("distinct",Word.DISTINCT4);
        dictionary.put("distinct",Word.DISTINCT5);
        dictionary.put("distinct",Word.DISTINCT6);
        dictionary.put("distinct",Word.DISTINCT7);
        dictionary.put("distinct",Word.DISTINCT8);
        dictionary.put("placeholder",Word.PLACEHOLDER1);
        dictionary.put("placeholder",Word.PLACEHOLDER2);
        dictionary.put("placeholder",Word.PLACEHOLDER3);
        dictionary.put("placeholder",Word.PLACEHOLDER4);
        dictionary.put("placeholder",Word.PLACEHOLDER5);
        dictionary.put("placeholder",Word.PLACEHOLDER6);
        dictionary.put("placeholder",Word.PLACEHOLDER7);
        dictionary.put("placeholder",Word.PLACEHOLDER8);
        dictionary.put("placeholder",Word.PLACEHOLDER9);
        dictionary.put("placeholder",Word.PLACEHOLDER10);
        dictionary.put("placeholder",Word.PLACEHOLDER11);
        dictionary.put("reverse",Word.REVERSE1);
        dictionary.put("reverse",Word.REVERSE2);
        dictionary.put("reverse",Word.REVERSE3);
        dictionary.put("reverse",Word.REVERSE4);
        dictionary.put("reverse",Word.REVERSE5);
        dictionary.put("reverse",Word.REVERSE6);
        dictionary.put("reverse",Word.REVERSE7);
        dictionary.put("reverse",Word.REVERSE8);
        dictionary.put("reverse",Word.REVERSE9);
        dictionary.put("reverse",Word.REVERSE10);
        dictionary.put("reverse",Word.REVERSE11);
        dictionary.put("reverse",Word.REVERSE12);
        dictionary.put("reverse",Word.REVERSE13);
        dictionary.put("reverse",Word.REVERSE14);
        dictionary.put("reverse",Word.REVERSE15);


        partOfSpeech.add("noun");
        partOfSpeech.add("adjective");
        partOfSpeech.add("verb");
        partOfSpeech.add("adverb");
        partOfSpeech.add("conjunction");
        partOfSpeech.add("interjection");
        partOfSpeech.add("preposition]");
        partOfSpeech.add("pronoun");

        boolean cont = true;
     int i=0;
     while (cont){
         i++;
         System.out.print("Search ["+ i+"]: ");
         String search  = input.nextLine().toLowerCase();
         String mainWord = getMainWord(search);

         int numberOfWord = countWord(search);
         if (!mainWord.equals("!q")) {
             mainPart(dictionary, mainWord, numberOfWord, search);
         }else{
             cont=false;
             System.out.println("-----THANK YOU-----");
         }

     }
    }
    public static void mainPart(ArrayListMultimap<String, Word> dictionary, String mainWord, int numberOfWord, String search){
        System.out.println("\t|");
        boolean cont =mainWordValidity(mainWord, search) ;

        if (cont){
        Collection<Word> mainCollection = getMainCollection(dictionary, mainWord);
        for (int p=0;p<1;p++) {
            if (getWordAtPosition(1, search) != null) {
                finalList.addAll(mainCollection);

            }
            if (getWordAtPosition(2, search) != null) {

                String second = getWordAtPosition(2, search);
                ArrayList<String> thisPartOfSpeech = getThisPartOfSpeech(mainCollection, second);

                if ((thisPartOfSpeech.contains(second))) {
                    finalList.clear();
                    ArrayList<Word> replace  = getSatisfied(mainCollection, second);
                    finalList.clear();
                    finalList.addAll(replace);

                }else if (partOfSpeech.contains(second)) {
                    notFoundPhrase();
                    finalList.clear();
                    break;
                }else if (second.equals("distinct")){
                    ArrayList<Word> replace =distinct();
                    finalList.clear();
                    finalList.addAll(replace);

                }else if (second.equals("reverse")){
                    ArrayList<Word> replace =reverse();
                    finalList.clear();
                    finalList.addAll(replace);
                }
                else{
                    System.out.println("\t<The entered 2nd parameter '"+second+"' is NOT a part of speech.>\n" +
                            "\t<The entered 2nd parameter '"+second+"' is NOT 'distinct'.>\n" +
                            "\t<The entered 2nd parameter '"+second+"' is NOT 'reverse'.>\n" +
                            "\t<The entered 2nd parameter '"+second+"' was disregarded.>\n" +
                            "\t<The 2nd parameter should be a part of speech or 'distinct' or 'reverse'.>\n\t|");
                }
            }
            if (getWordAtPosition(3, search)!=null){
                String third = getWordAtPosition(3, search);
                for (int i=0;i<1;i++){
                    if (third.equals("distinct")){
                        ArrayList<Word> replace =distinct();
                        finalList.clear();
                        finalList.addAll(replace);

                    }else if (third.equals("reverse")){
                        ArrayList<Word> replace =reverse();
                        finalList.clear();
                        finalList.addAll(replace);
                    }
                    else{
                        System.out.println("\t<The entered 3rd parameter '"+third+"' is NOT 'distinct'.>\n" +
                                "\t<The entered 3rd parameter '"+third+"' is NOT 'reverse'.>\n" +
                                "\t<The entered 3rd parameter '"+third+"' was disregarded.>\n" +
                                "\t<The 3rd parameter should be 'distinct' or 'reverse'.>\n" +
                                "\t|");
                    }
                }
            }if (getWordAtPosition(4, search)!=null) {
                String fourth = getWordAtPosition(4, search);
                for (int i=0;i<1;i++){
                    if (fourth.equals("reverse")){
                        ArrayList<Word> replace =reverse();
                        finalList.clear();
                        finalList.addAll(replace);
                    }
                    else{
                        System.out.println("\t<The entered 4th parameter '"+fourth+"' is NOT 'reverse'.>\n" +
                                "\t<The entered 4th parameter '"+fourth+"' was disregarded.>\n" +
                                "\t<The 4th parameter should be 'reverse'.>\n" +
                                "\t|");
                    }
                }
            }
            }
        }else if ((search.equals("!help"))||(search.equals(""))||(countWord(search)>4)){
            System.out.println("\tPARAMETER HOW-TO, please enter:\n" +
                    "\t1. A search key -then 2. An optional part of speech -then\n" +
                    "\t3. An optional 'distinct' -then 4. An optional 'reverse'");
        }
        else{
            notFoundPhrase();
        }if (!finalList.isEmpty()){
            for (Word word : finalList){
               System.out.println(word);
            }
        }
        System.out.println("\t|");
        finalList.clear();

    }public static  ArrayList<Word> distinct(){
        ArrayList<String> list = new ArrayList<>();
        ArrayList<Word> last = new ArrayList<>();

        ArrayListMultimap<String, Word> check = ArrayListMultimap.create();
        for (Word word : finalList){
            if ((!list.contains(word.getMeaning()))){
                list.add(word.getMeaning());
            }
            check.put(word.getMeaning(), word);
            last.add(word);
        }
        ArrayList<Word> last2 = new ArrayList<>();

        for (int i=0;i<list.size();i++){
            Collection<Word> collection = check.get(list.get(i));
            ArrayList<String> list2 = new ArrayList<>();

            for (Word e: collection){
                if (!list2.contains(e.getType())){
                   last2.add(e);
                   list2.add(e.getType());
               }

            }
        }
        return last2;
    }public static ArrayList<Word> reverse(){
        ArrayList<Word> list = new ArrayList<>();
        int o=0;
        for (int i= finalList.size()-1;i>=0;i--){
            list.add(o,finalList.get(i));
            o++;
        }

        return list;
    }

    public static void notFoundPhrase(){
        System.out.println("\t<NOT FOUND> To be considered for the next release. Thank you. \n\t|\n\t|");
        System.out.println("\tPARAMETER HOW-TO, please enter:\n" +
                "\t1. A search key -then 2. An optional part of speech -then\n" +
                "\t3. An optional 'distinct' -then 4. An optional 'reverse'");
    }
    public static boolean mainWordValidity(String mainWord, String search){
        boolean cont=false;
        ArrayList<String> words = new ArrayList<>();
        words.add("arrow");
        words.add("placeholder");
        words.add("distinct");
        words.add("reverse");
        words.add("book");

        if (words.contains(mainWord)){
            if (countWord(search)<=4){
                cont=true;
            }
        }

        return cont;
    }

    public static ArrayList<String> getThisPartOfSpeech(Collection<Word> mainCollection, String second) {
        ArrayList<String> list = new ArrayList<>();
        for (Word e : mainCollection){
            if (e.getType().equals(second)){
                list.add(second);
            }
        }return list;
    }

    public  static ArrayList<Word> getSatisfied(Collection<Word> mainCollection, String second) {
        ArrayList<Word> list = new ArrayList<>();
        for (Word word : mainCollection){
            if (second.equals(word.getType())){
                list.add(word);
            }
        }return list;
    }

    public static String getWordAtPosition(int index, String search){
        int word=0;
        String string = null;
        if (index==1){
            string = getMainWord(search);
        }else {
            if (index <= countWord(search)) {
                for (int i = 0; i < search.length(); i++) {
                    if (search.charAt(i) != ' ') {
                        string = string + search.charAt(i);
                    } else {
                        word++;
                        if (word == index) {
                            break;
                        }
                        string = "";
                    }
                }
            }
        }
        return string;
    }

    public static String getMainWord (String search){
        String firstWord ="";
        for (int i=0;i<search.length();i++){
            if (search.charAt(i) != ' '){
                firstWord=firstWord+(search.charAt(i));
            }else{
                break;
            }
        }

        return firstWord;
    }
    public static int countWord(String input){
        int numberOfWord=1;
        for (int i=0;i<input.length()-1;i++){
            if ((input.charAt(i)==' ')){
                numberOfWord++;
            }
        }return numberOfWord;
    }public static Collection<Word> getMainCollection(ArrayListMultimap<String, Word> dictionary, String mainWord){
        Collection<Word> arrow = dictionary.get("arrow");
        Collection<Word> book = dictionary.get("book");
        Collection<Word> distinct = dictionary.get("distinct");
        Collection<Word> reverse = dictionary.get("reverse");
        Collection<Word> placeholder = dictionary.get("placeholder");

        switch (mainWord){
            case "book" -> {
                return book;
            }case "distinct"-> {
                return distinct;
            }case "reverse"-> {
                return reverse;
            }case "placeholder"-> {
                return placeholder;
            }case "arrow"->{
                return arrow;
            }
        }return book;
    }
}
enum Word{
    ARROW("Arrow","noun","Here is one arrow: <IMG> -=>> </IMG>"),
    BOOK1("Book","noun","A set of pages"),
    BOOK2("Book","noun", "A written work published in printed or electronic form"),
    BOOK3("Book","verb","To arrange for someone to have a seat on a plane"),
    BOOK4("Book","verb","To arrange something on a particular date"),

    DISTINCT1("Distinct","adjective","Familiar. Worked in Java"),
    DISTINCT2("Distinct","adjective","Unique. No duplicates. Clearly different or of a different kind"),
    DISTINCT3("Distinct","adverb","Uniquely. Written \"distinctly\""),
    DISTINCT4("Distinct","noun","A keyword in this assignment"),
    DISTINCT5("Distinct","noun","A keyword in this assignment"),
    DISTINCT6("Distinct","noun","A keyword in this assignment"),
    DISTINCT7("Distinct","noun","An advanced search option"),
    DISTINCT8("Distinct","noun","Distinct is a parameter in this assignment"),

    PLACEHOLDER1("Placeholder","adjective","To be updated..."),
    PLACEHOLDER2("Placeholder","adjective","To be updated..."),
    PLACEHOLDER3("Placeholder","adverb","To be updated..."),
    PLACEHOLDER4("Placeholder","conjunction","To be updated..."),
    PLACEHOLDER5("Placeholder","interjection","To be updated..."),
    PLACEHOLDER6("Placeholder","noun","To be updated..."),
    PLACEHOLDER7("Placeholder","noun","To be updated..."),
    PLACEHOLDER8("Placeholder","noun","To be updated..."),
    PLACEHOLDER9("Placeholder","preposition","To be updated..."),
    PLACEHOLDER10("Placeholder","pronoun","To be updated..."),
    PLACEHOLDER11("Placeholder","verb","To be updated..."),

    REVERSE1("Reverse","adjective","On back side"),
    REVERSE2("Reverse","adjective","Opposite to usual or previous arrangement"),
    REVERSE3("Reverse","noun","A dictionary program's parameter"),
    REVERSE4("Reverse","noun","Change to opposite direction"),
    REVERSE5("Reverse","noun","The opposite"),
    REVERSE6("Reverse","noun","To be updated..."),
    REVERSE7("Reverse","noun","To be updated..."),
    REVERSE8("Reverse","noun","To be updated..."),
    REVERSE9("Reverse","noun","To be updated..."),
    REVERSE10("Reverse","verb","Change something to opposite"),
    REVERSE11("Reverse","verb","Go back"),
    REVERSE12("Reverse","verb","Revoke ruling"),
    REVERSE13("Reverse","verb","To be updated..."),
    REVERSE14("Reverse","verb","To be updated..."),
    REVERSE15("Reverse","verb","Turn something inside out");

    private String word;
    private String meaning;
    private String type;


    Word(String word, String type, String meaning){
        this.word = word;
        this.type = type;
        this.meaning = meaning;
    }
    public String getType() {
        return type;
    }

    public String getMeaning() {
        return meaning;
    }
    public String getWord() {
        return word;
    }
    public String toString(){
        return "\t "+this.word+" ["+this.type+"] : "+ this.meaning ;
    }
}

